export interface Attributes {
	productId: number;
	isDescendentOfQueryLoop: boolean;
	isDescendentOfSingleProductTemplate: boolean;
	isDescendentOfSingleProductBlock: boolean;
	showProductSelector: boolean;
	isDescendantOfAllProducts: boolean;
}
