<?php

namespace Automattic\WooCommerce\Vendor\Psr\Container;

/**
 * Base interface representing a generic exception in a container.
 */
interface ContainerExceptionInterface
{
}
