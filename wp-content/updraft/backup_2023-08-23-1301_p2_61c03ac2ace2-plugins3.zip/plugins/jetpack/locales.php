<?php
/**
 * Duplicated from the GlotPress/GlotPress-WP project.
 *
 * @package automattic/jetpack
 */

/**
 * Import file from compat package.
 *
 * @deprecated Please use 'projects/packages/compat/lib/locales.php' instead.
 */
require_once JETPACK__PLUGIN_DIR . 'jetpack_vendor/automattic/jetpack-compat/lib/locales.php';
